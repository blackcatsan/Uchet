﻿
namespace Uchet
{
    partial class Change_Prep_Form_kabs
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.pnumDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pnamDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.labhoursDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.specDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tnumDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pnumDataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tnumDataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tfamDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tnamDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.totchDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dolgDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.teachers1BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.kazakovDataSet = new Uchet.KazakovDataSet();
            this.specDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.labhoursDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pnamDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SelectdataGridViewCheckBoxColumn1 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.pnumDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.teachers1TableAdapter = new Uchet.KazakovDataSetTableAdapters.Teachers1TableAdapter();
            this.kabsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.kabsTableAdapter = new Uchet.KazakovDataSetTableAdapters.KabsTableAdapter();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.button3 = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.teachers1BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kazakovDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kabsBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // pnumDataGridViewTextBoxColumn2
            // 
            this.pnumDataGridViewTextBoxColumn2.DataPropertyName = "pnum";
            this.pnumDataGridViewTextBoxColumn2.HeaderText = "pnum";
            this.pnumDataGridViewTextBoxColumn2.MinimumWidth = 8;
            this.pnumDataGridViewTextBoxColumn2.Name = "pnumDataGridViewTextBoxColumn2";
            this.pnumDataGridViewTextBoxColumn2.Width = 162;
            // 
            // pnamDataGridViewTextBoxColumn1
            // 
            this.pnamDataGridViewTextBoxColumn1.DataPropertyName = "pnam";
            this.pnamDataGridViewTextBoxColumn1.HeaderText = "pnam";
            this.pnamDataGridViewTextBoxColumn1.MinimumWidth = 8;
            this.pnamDataGridViewTextBoxColumn1.Name = "pnamDataGridViewTextBoxColumn1";
            this.pnamDataGridViewTextBoxColumn1.Width = 161;
            // 
            // labhoursDataGridViewTextBoxColumn1
            // 
            this.labhoursDataGridViewTextBoxColumn1.DataPropertyName = "lab_hours";
            this.labhoursDataGridViewTextBoxColumn1.HeaderText = "lab_hours";
            this.labhoursDataGridViewTextBoxColumn1.MinimumWidth = 8;
            this.labhoursDataGridViewTextBoxColumn1.Name = "labhoursDataGridViewTextBoxColumn1";
            this.labhoursDataGridViewTextBoxColumn1.Width = 162;
            // 
            // specDataGridViewTextBoxColumn1
            // 
            this.specDataGridViewTextBoxColumn1.DataPropertyName = "spec";
            this.specDataGridViewTextBoxColumn1.HeaderText = "spec";
            this.specDataGridViewTextBoxColumn1.MinimumWidth = 8;
            this.specDataGridViewTextBoxColumn1.Name = "specDataGridViewTextBoxColumn1";
            this.specDataGridViewTextBoxColumn1.Width = 161;
            // 
            // tnumDataGridViewTextBoxColumn2
            // 
            this.tnumDataGridViewTextBoxColumn2.DataPropertyName = "tnum";
            this.tnumDataGridViewTextBoxColumn2.HeaderText = "tnum";
            this.tnumDataGridViewTextBoxColumn2.MinimumWidth = 8;
            this.tnumDataGridViewTextBoxColumn2.Name = "tnumDataGridViewTextBoxColumn2";
            this.tnumDataGridViewTextBoxColumn2.Width = 119;
            // 
            // pnumDataGridViewTextBoxColumn3
            // 
            this.pnumDataGridViewTextBoxColumn3.DataPropertyName = "pnum";
            this.pnumDataGridViewTextBoxColumn3.HeaderText = "pnum";
            this.pnumDataGridViewTextBoxColumn3.MinimumWidth = 8;
            this.pnumDataGridViewTextBoxColumn3.Name = "pnumDataGridViewTextBoxColumn3";
            this.pnumDataGridViewTextBoxColumn3.Width = 118;
            // 
            // tnumDataGridViewTextBoxColumn3
            // 
            this.tnumDataGridViewTextBoxColumn3.DataPropertyName = "tnum";
            this.tnumDataGridViewTextBoxColumn3.HeaderText = "tnum";
            this.tnumDataGridViewTextBoxColumn3.MinimumWidth = 8;
            this.tnumDataGridViewTextBoxColumn3.Name = "tnumDataGridViewTextBoxColumn3";
            this.tnumDataGridViewTextBoxColumn3.Width = 129;
            // 
            // tfamDataGridViewTextBoxColumn1
            // 
            this.tfamDataGridViewTextBoxColumn1.DataPropertyName = "tfam";
            this.tfamDataGridViewTextBoxColumn1.HeaderText = "tfam";
            this.tfamDataGridViewTextBoxColumn1.MinimumWidth = 8;
            this.tfamDataGridViewTextBoxColumn1.Name = "tfamDataGridViewTextBoxColumn1";
            this.tfamDataGridViewTextBoxColumn1.Width = 129;
            // 
            // tnamDataGridViewTextBoxColumn1
            // 
            this.tnamDataGridViewTextBoxColumn1.DataPropertyName = "tnam";
            this.tnamDataGridViewTextBoxColumn1.HeaderText = "tnam";
            this.tnamDataGridViewTextBoxColumn1.MinimumWidth = 8;
            this.tnamDataGridViewTextBoxColumn1.Name = "tnamDataGridViewTextBoxColumn1";
            this.tnamDataGridViewTextBoxColumn1.Width = 130;
            // 
            // totchDataGridViewTextBoxColumn1
            // 
            this.totchDataGridViewTextBoxColumn1.DataPropertyName = "totch";
            this.totchDataGridViewTextBoxColumn1.HeaderText = "totch";
            this.totchDataGridViewTextBoxColumn1.MinimumWidth = 8;
            this.totchDataGridViewTextBoxColumn1.Name = "totchDataGridViewTextBoxColumn1";
            this.totchDataGridViewTextBoxColumn1.Width = 129;
            // 
            // dolgDataGridViewTextBoxColumn1
            // 
            this.dolgDataGridViewTextBoxColumn1.DataPropertyName = "dolg";
            this.dolgDataGridViewTextBoxColumn1.HeaderText = "dolg";
            this.dolgDataGridViewTextBoxColumn1.MinimumWidth = 8;
            this.dolgDataGridViewTextBoxColumn1.Name = "dolgDataGridViewTextBoxColumn1";
            this.dolgDataGridViewTextBoxColumn1.Width = 129;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "tnum";
            this.dataGridViewTextBoxColumn3.HeaderText = "tnum";
            this.dataGridViewTextBoxColumn3.MinimumWidth = 8;
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.Width = 119;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "pnum";
            this.dataGridViewTextBoxColumn4.HeaderText = "pnum";
            this.dataGridViewTextBoxColumn4.MinimumWidth = 8;
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.Width = 118;
            // 
            // teachers1BindingSource
            // 
            this.teachers1BindingSource.DataMember = "Teachers1";
            this.teachers1BindingSource.DataSource = this.kazakovDataSet;
            // 
            // kazakovDataSet
            // 
            this.kazakovDataSet.DataSetName = "KazakovDataSet";
            this.kazakovDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // specDataGridViewTextBoxColumn
            // 
            this.specDataGridViewTextBoxColumn.DataPropertyName = "spec";
            this.specDataGridViewTextBoxColumn.HeaderText = "spec";
            this.specDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.specDataGridViewTextBoxColumn.Name = "specDataGridViewTextBoxColumn";
            this.specDataGridViewTextBoxColumn.Width = 150;
            // 
            // labhoursDataGridViewTextBoxColumn
            // 
            this.labhoursDataGridViewTextBoxColumn.DataPropertyName = "lab_hours";
            this.labhoursDataGridViewTextBoxColumn.HeaderText = "lab_hours";
            this.labhoursDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.labhoursDataGridViewTextBoxColumn.Name = "labhoursDataGridViewTextBoxColumn";
            this.labhoursDataGridViewTextBoxColumn.Width = 150;
            // 
            // pnamDataGridViewTextBoxColumn
            // 
            this.pnamDataGridViewTextBoxColumn.DataPropertyName = "pnam";
            this.pnamDataGridViewTextBoxColumn.HeaderText = "pnam";
            this.pnamDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.pnamDataGridViewTextBoxColumn.Name = "pnamDataGridViewTextBoxColumn";
            this.pnamDataGridViewTextBoxColumn.Width = 150;
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "tnum";
            this.dataGridViewTextBoxColumn9.HeaderText = "tnum";
            this.dataGridViewTextBoxColumn9.MinimumWidth = 8;
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            this.dataGridViewTextBoxColumn9.Width = 150;
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.DataPropertyName = "pnum";
            this.dataGridViewTextBoxColumn10.HeaderText = "pnum";
            this.dataGridViewTextBoxColumn10.MinimumWidth = 8;
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            this.dataGridViewTextBoxColumn10.Width = 150;
            // 
            // SelectdataGridViewCheckBoxColumn1
            // 
            this.SelectdataGridViewCheckBoxColumn1.HeaderText = "Select";
            this.SelectdataGridViewCheckBoxColumn1.MinimumWidth = 8;
            this.SelectdataGridViewCheckBoxColumn1.Name = "SelectdataGridViewCheckBoxColumn1";
            this.SelectdataGridViewCheckBoxColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.SelectdataGridViewCheckBoxColumn1.Width = 150;
            // 
            // pnumDataGridViewTextBoxColumn
            // 
            this.pnumDataGridViewTextBoxColumn.DataPropertyName = "pnum";
            this.pnumDataGridViewTextBoxColumn.HeaderText = "pnum";
            this.pnumDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.pnumDataGridViewTextBoxColumn.Name = "pnumDataGridViewTextBoxColumn";
            this.pnumDataGridViewTextBoxColumn.Width = 150;
            // 
            // teachers1TableAdapter
            // 
            this.teachers1TableAdapter.ClearBeforeFill = true;
            // 
            // kabsBindingSource
            // 
            this.kabsBindingSource.DataMember = "Kabs";
            this.kabsBindingSource.DataSource = this.kazakovDataSet;
            // 
            // kabsTableAdapter
            // 
            this.kabsTableAdapter.ClearBeforeFill = true;
            // 
            // comboBox1
            // 
            this.comboBox1.DataSource = this.teachers1BindingSource;
            this.comboBox1.DisplayMember = "fam";
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(440, 84);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(187, 28);
            this.comboBox1.TabIndex = 17;
            this.comboBox1.ValueMember = "tnum";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(319, 155);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(100, 37);
            this.button3.TabIndex = 16;
            this.button3.Text = "Изменить";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(440, 59);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(130, 20);
            this.label12.TabIndex = 15;
            this.label12.Text = "Ответственный";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(229, 60);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(134, 20);
            this.label11.TabIndex = 14;
            this.label11.Text = "Номер кабинета";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(85, 58);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(39, 20);
            this.label10.TabIndex = 13;
            this.label10.Text = "Код";
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(233, 84);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(170, 26);
            this.textBox11.TabIndex = 12;
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(85, 84);
            this.textBox10.Name = "textBox10";
            this.textBox10.ReadOnly = true;
            this.textBox10.Size = new System.Drawing.Size(100, 26);
            this.textBox10.TabIndex = 11;
            // 
            // Change_Prep_Form_kabs
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(705, 258);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.textBox11);
            this.Controls.Add(this.textBox10);
            this.Name = "Change_Prep_Form_kabs";
            this.Text = "Изменить кабинет";
            this.Load += new System.EventHandler(this.Change_Prep_Form_kabs_Load);
            ((System.ComponentModel.ISupportInitialize)(this.teachers1BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kazakovDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kabsBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridViewTextBoxColumn pnumDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn pnamDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn labhoursDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn specDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn tnumDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn pnumDataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn tnumDataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn tfamDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn tnamDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn totchDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dolgDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn specDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn labhoursDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pnamDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewCheckBoxColumn SelectdataGridViewCheckBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn pnumDataGridViewTextBoxColumn;
        private KazakovDataSet kazakovDataSet;
        private System.Windows.Forms.BindingSource teachers1BindingSource;
        private KazakovDataSetTableAdapters.Teachers1TableAdapter teachers1TableAdapter;
        private System.Windows.Forms.BindingSource kabsBindingSource;
        private KazakovDataSetTableAdapters.KabsTableAdapter kabsTableAdapter;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox textBox10;
    }
}