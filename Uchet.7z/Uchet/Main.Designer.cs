﻿namespace Uchet
{
    partial class Main
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.button14 = new System.Windows.Forms.Button();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.button10 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.dataGridView4 = new System.Windows.Forms.DataGridView();
            this.tnumDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pnumDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.prepodavBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.kazakovDataSet = new Uchet.KazakovDataSet();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.knumDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.knamDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.teachDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.kabsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.pnumDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pnamDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.labhoursDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.specDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.predmetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.tnumDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tfamDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tnamDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.totchDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dolgDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.teachersBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.button15 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.button11 = new System.Windows.Forms.Button();
            this.dataGridView10 = new System.Windows.Forms.DataGridView();
            this.lnumDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lnamDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dlitDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.licenseBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.button8 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.dataGridView9 = new System.Windows.Forms.DataGridView();
            this.pnumDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pnamDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.labhoursDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.specDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridView8 = new System.Windows.Forms.DataGridView();
            this.progDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.predmDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.progPredBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataGridView7 = new System.Windows.Forms.DataGridView();
            this.progDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pcDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.installBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataGridView6 = new System.Windows.Forms.DataGridView();
            this.pCnumDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pCnetDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.kabDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.knamDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pC1BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataGridView5 = new System.Windows.Forms.DataGridView();
            this.prnumDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.prnamDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.versionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.licenseDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.instdatDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.exprdatDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.valueDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.programsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.button13 = new System.Windows.Forms.Button();
            this.dataGridView11 = new System.Windows.Forms.DataGridView();
            this.snumDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.snamDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.roleDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sotrBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.менюToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.обновитьТаблицыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.статистикаОбновленияToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.сменитьПользователяToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.выходToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.экспортToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.преподавателиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.программноеОбеспечениеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.оПрограммеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.оПрограммеToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.teachersTableAdapter = new Uchet.KazakovDataSetTableAdapters.TeachersTableAdapter();
            this.kabsTableAdapter = new Uchet.KazakovDataSetTableAdapters.KabsTableAdapter();
            this.predmetTableAdapter = new Uchet.KazakovDataSetTableAdapters.PredmetTableAdapter();
            this.prepodavTableAdapter = new Uchet.KazakovDataSetTableAdapters.PrepodavTableAdapter();
            this.programsTableAdapter = new Uchet.KazakovDataSetTableAdapters.ProgramsTableAdapter();
            this.licenseTableAdapter = new Uchet.KazakovDataSetTableAdapters.LicenseTableAdapter();
            this.pCBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.pCTableAdapter = new Uchet.KazakovDataSetTableAdapters.PCTableAdapter();
            this.pC1TableAdapter = new Uchet.KazakovDataSetTableAdapters.PC1TableAdapter();
            this.sotrTableAdapter = new Uchet.KazakovDataSetTableAdapters.SotrTableAdapter();
            this.progPredTableAdapter = new Uchet.KazakovDataSetTableAdapters.ProgPredTableAdapter();
            this.installTableAdapter = new Uchet.KazakovDataSetTableAdapters.InstallTableAdapter();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.prepodavBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kazakovDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kabsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.predmetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.teachersBindingSource)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.licenseBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.progPredBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.installBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pC1BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.programsBindingSource)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sotrBindingSource)).BeginInit();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pCBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 33);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1218, 659);
            this.tabControl1.TabIndex = 0;
            this.tabControl1.SelectedIndexChanged += new System.EventHandler(this.tabControl1_SelectedIndexChanged_1);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.button14);
            this.tabPage1.Controls.Add(this.label16);
            this.tabPage1.Controls.Add(this.label15);
            this.tabPage1.Controls.Add(this.label14);
            this.tabPage1.Controls.Add(this.label13);
            this.tabPage1.Controls.Add(this.textBox4);
            this.tabPage1.Controls.Add(this.textBox3);
            this.tabPage1.Controls.Add(this.textBox2);
            this.tabPage1.Controls.Add(this.textBox1);
            this.tabPage1.Controls.Add(this.label7);
            this.tabPage1.Controls.Add(this.label6);
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Controls.Add(this.button10);
            this.tabPage1.Controls.Add(this.button9);
            this.tabPage1.Controls.Add(this.button5);
            this.tabPage1.Controls.Add(this.dataGridView4);
            this.tabPage1.Controls.Add(this.button2);
            this.tabPage1.Controls.Add(this.button1);
            this.tabPage1.Controls.Add(this.dataGridView3);
            this.tabPage1.Controls.Add(this.dataGridView2);
            this.tabPage1.Controls.Add(this.dataGridView1);
            this.tabPage1.Location = new System.Drawing.Point(4, 29);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabPage1.Size = new System.Drawing.Size(1210, 626);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Преподаватели";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // button14
            // 
            this.button14.Location = new System.Drawing.Point(1018, 577);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(138, 35);
            this.button14.TabIndex = 29;
            this.button14.Text = "Экспорт";
            this.button14.UseVisualStyleBackColor = true;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(221, 23);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(81, 20);
            this.label16.TabIndex = 23;
            this.label16.Text = "Фамилия";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(1012, 23);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(101, 20);
            this.label15.TabIndex = 22;
            this.label15.Text = "№ Кабинета";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(402, 344);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(122, 20);
            this.label14.TabIndex = 21;
            this.label14.Text = "Наименование";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(1016, 344);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(128, 20);
            this.label13.TabIndex = 20;
            this.label13.Text = "Специальность";
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(880, 367);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(276, 26);
            this.textBox4.TabIndex = 19;
            this.textBox4.TextChanged += new System.EventHandler(this.textBox4_TextChanged);
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(330, 367);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(272, 26);
            this.textBox3.TabIndex = 18;
            this.textBox3.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(997, 46);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(159, 26);
            this.textBox2.TabIndex = 17;
            this.textBox2.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(206, 46);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(147, 26);
            this.textBox1.TabIndex = 16;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(48, 373);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(79, 20);
            this.label7.TabIndex = 15;
            this.label7.Text = "Предмет";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(828, 52);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(73, 20);
            this.label6.TabIndex = 14;
            this.label6.Text = "Кабинет";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(48, 52);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(132, 20);
            this.label5.TabIndex = 13;
            this.label5.Text = "Преподаватель";
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(832, 311);
            this.button10.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(177, 35);
            this.button10.TabIndex = 8;
            this.button10.Text = "Изменить кабинет";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Visible = false;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(52, 312);
            this.button9.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(235, 35);
            this.button9.TabIndex = 7;
            this.button9.Text = "Изменить преподавателя";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Visible = false;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(832, 577);
            this.button5.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(159, 35);
            this.button5.TabIndex = 6;
            this.button5.Text = "Сброс фильтра";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // dataGridView4
            // 
            this.dataGridView4.AllowUserToAddRows = false;
            this.dataGridView4.AllowUserToDeleteRows = false;
            this.dataGridView4.AllowUserToResizeColumns = false;
            this.dataGridView4.AllowUserToResizeRows = false;
            this.dataGridView4.AutoGenerateColumns = false;
            this.dataGridView4.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView4.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.tnumDataGridViewTextBoxColumn1,
            this.pnumDataGridViewTextBoxColumn1});
            this.dataGridView4.DataSource = this.prepodavBindingSource;
            this.dataGridView4.Location = new System.Drawing.Point(1199, 77);
            this.dataGridView4.Name = "dataGridView4";
            this.dataGridView4.ReadOnly = true;
            this.dataGridView4.RowHeadersVisible = false;
            this.dataGridView4.RowHeadersWidth = 62;
            this.dataGridView4.RowTemplate.Height = 28;
            this.dataGridView4.Size = new System.Drawing.Size(240, 494);
            this.dataGridView4.TabIndex = 5;
            this.dataGridView4.Visible = false;
            // 
            // tnumDataGridViewTextBoxColumn1
            // 
            this.tnumDataGridViewTextBoxColumn1.DataPropertyName = "tnum";
            this.tnumDataGridViewTextBoxColumn1.HeaderText = "tnum";
            this.tnumDataGridViewTextBoxColumn1.MinimumWidth = 8;
            this.tnumDataGridViewTextBoxColumn1.Name = "tnumDataGridViewTextBoxColumn1";
            this.tnumDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // pnumDataGridViewTextBoxColumn1
            // 
            this.pnumDataGridViewTextBoxColumn1.DataPropertyName = "pnum";
            this.pnumDataGridViewTextBoxColumn1.HeaderText = "pnum";
            this.pnumDataGridViewTextBoxColumn1.MinimumWidth = 8;
            this.pnumDataGridViewTextBoxColumn1.Name = "pnumDataGridViewTextBoxColumn1";
            this.pnumDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // prepodavBindingSource
            // 
            this.prepodavBindingSource.DataMember = "Prepodav";
            this.prepodavBindingSource.DataSource = this.kazakovDataSet;
            // 
            // kazakovDataSet
            // 
            this.kazakovDataSet.DataSetName = "KazakovDataSet";
            this.kazakovDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(52, 577);
            this.button2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(187, 35);
            this.button2.TabIndex = 4;
            this.button2.Text = "Изменить предмет";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Visible = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(52, 5);
            this.button1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(112, 35);
            this.button1.TabIndex = 3;
            this.button1.Text = "Добавить";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Visible = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // dataGridView3
            // 
            this.dataGridView3.AllowUserToAddRows = false;
            this.dataGridView3.AllowUserToDeleteRows = false;
            this.dataGridView3.AllowUserToResizeColumns = false;
            this.dataGridView3.AllowUserToResizeRows = false;
            this.dataGridView3.AutoGenerateColumns = false;
            this.dataGridView3.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.knumDataGridViewTextBoxColumn,
            this.knamDataGridViewTextBoxColumn,
            this.teachDataGridViewTextBoxColumn});
            this.dataGridView3.DataSource = this.kabsBindingSource;
            this.dataGridView3.Location = new System.Drawing.Point(832, 77);
            this.dataGridView3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.ReadOnly = true;
            this.dataGridView3.RowHeadersVisible = false;
            this.dataGridView3.RowHeadersWidth = 62;
            this.dataGridView3.RowTemplate.Height = 23;
            this.dataGridView3.Size = new System.Drawing.Size(324, 231);
            this.dataGridView3.TabIndex = 2;
            this.dataGridView3.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView3_CellDoubleClick);
            // 
            // knumDataGridViewTextBoxColumn
            // 
            this.knumDataGridViewTextBoxColumn.DataPropertyName = "knum";
            this.knumDataGridViewTextBoxColumn.FillWeight = 50F;
            this.knumDataGridViewTextBoxColumn.HeaderText = "Код";
            this.knumDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.knumDataGridViewTextBoxColumn.Name = "knumDataGridViewTextBoxColumn";
            this.knumDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // knamDataGridViewTextBoxColumn
            // 
            this.knamDataGridViewTextBoxColumn.DataPropertyName = "knam";
            this.knamDataGridViewTextBoxColumn.FillWeight = 75F;
            this.knamDataGridViewTextBoxColumn.HeaderText = "№ кабинета";
            this.knamDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.knamDataGridViewTextBoxColumn.Name = "knamDataGridViewTextBoxColumn";
            this.knamDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // teachDataGridViewTextBoxColumn
            // 
            this.teachDataGridViewTextBoxColumn.DataPropertyName = "teach";
            this.teachDataGridViewTextBoxColumn.HeaderText = "Ответственный";
            this.teachDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.teachDataGridViewTextBoxColumn.Name = "teachDataGridViewTextBoxColumn";
            this.teachDataGridViewTextBoxColumn.ReadOnly = true;
            this.teachDataGridViewTextBoxColumn.Visible = false;
            // 
            // kabsBindingSource
            // 
            this.kabsBindingSource.DataMember = "Kabs";
            this.kabsBindingSource.DataSource = this.kazakovDataSet;
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToAddRows = false;
            this.dataGridView2.AllowUserToDeleteRows = false;
            this.dataGridView2.AllowUserToResizeColumns = false;
            this.dataGridView2.AllowUserToResizeRows = false;
            this.dataGridView2.AutoGenerateColumns = false;
            this.dataGridView2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.pnumDataGridViewTextBoxColumn,
            this.pnamDataGridViewTextBoxColumn,
            this.labhoursDataGridViewTextBoxColumn,
            this.specDataGridViewTextBoxColumn});
            this.dataGridView2.DataSource = this.predmetBindingSource;
            this.dataGridView2.Location = new System.Drawing.Point(52, 398);
            this.dataGridView2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.RowHeadersVisible = false;
            this.dataGridView2.RowHeadersWidth = 62;
            this.dataGridView2.RowTemplate.Height = 23;
            this.dataGridView2.Size = new System.Drawing.Size(1104, 173);
            this.dataGridView2.TabIndex = 1;
            this.dataGridView2.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellClick);
            // 
            // pnumDataGridViewTextBoxColumn
            // 
            this.pnumDataGridViewTextBoxColumn.DataPropertyName = "pnum";
            this.pnumDataGridViewTextBoxColumn.HeaderText = "Код";
            this.pnumDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.pnumDataGridViewTextBoxColumn.Name = "pnumDataGridViewTextBoxColumn";
            this.pnumDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // pnamDataGridViewTextBoxColumn
            // 
            this.pnamDataGridViewTextBoxColumn.DataPropertyName = "pnam";
            this.pnamDataGridViewTextBoxColumn.HeaderText = "Наименование";
            this.pnamDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.pnamDataGridViewTextBoxColumn.Name = "pnamDataGridViewTextBoxColumn";
            this.pnamDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // labhoursDataGridViewTextBoxColumn
            // 
            this.labhoursDataGridViewTextBoxColumn.DataPropertyName = "lab_hours";
            this.labhoursDataGridViewTextBoxColumn.HeaderText = "Лабораторные, часы";
            this.labhoursDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.labhoursDataGridViewTextBoxColumn.Name = "labhoursDataGridViewTextBoxColumn";
            this.labhoursDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // specDataGridViewTextBoxColumn
            // 
            this.specDataGridViewTextBoxColumn.DataPropertyName = "spec";
            this.specDataGridViewTextBoxColumn.HeaderText = "Специальность";
            this.specDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.specDataGridViewTextBoxColumn.Name = "specDataGridViewTextBoxColumn";
            this.specDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // predmetBindingSource
            // 
            this.predmetBindingSource.DataMember = "Predmet";
            this.predmetBindingSource.DataSource = this.kazakovDataSet;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToResizeColumns = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.tnumDataGridViewTextBoxColumn,
            this.tfamDataGridViewTextBoxColumn,
            this.tnamDataGridViewTextBoxColumn,
            this.totchDataGridViewTextBoxColumn,
            this.dolgDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.teachersBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(52, 77);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.RowHeadersWidth = 62;
            this.dataGridView1.RowTemplate.Height = 23;
            this.dataGridView1.Size = new System.Drawing.Size(754, 231);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // tnumDataGridViewTextBoxColumn
            // 
            this.tnumDataGridViewTextBoxColumn.DataPropertyName = "tnum";
            this.tnumDataGridViewTextBoxColumn.HeaderText = "Код";
            this.tnumDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.tnumDataGridViewTextBoxColumn.Name = "tnumDataGridViewTextBoxColumn";
            this.tnumDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // tfamDataGridViewTextBoxColumn
            // 
            this.tfamDataGridViewTextBoxColumn.DataPropertyName = "tfam";
            this.tfamDataGridViewTextBoxColumn.HeaderText = "Фамилия";
            this.tfamDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.tfamDataGridViewTextBoxColumn.Name = "tfamDataGridViewTextBoxColumn";
            this.tfamDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // tnamDataGridViewTextBoxColumn
            // 
            this.tnamDataGridViewTextBoxColumn.DataPropertyName = "tnam";
            this.tnamDataGridViewTextBoxColumn.HeaderText = "Имя";
            this.tnamDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.tnamDataGridViewTextBoxColumn.Name = "tnamDataGridViewTextBoxColumn";
            this.tnamDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // totchDataGridViewTextBoxColumn
            // 
            this.totchDataGridViewTextBoxColumn.DataPropertyName = "totch";
            this.totchDataGridViewTextBoxColumn.HeaderText = "Отчество";
            this.totchDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.totchDataGridViewTextBoxColumn.Name = "totchDataGridViewTextBoxColumn";
            this.totchDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // dolgDataGridViewTextBoxColumn
            // 
            this.dolgDataGridViewTextBoxColumn.DataPropertyName = "dolg";
            this.dolgDataGridViewTextBoxColumn.HeaderText = "Должность";
            this.dolgDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.dolgDataGridViewTextBoxColumn.Name = "dolgDataGridViewTextBoxColumn";
            this.dolgDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // teachersBindingSource
            // 
            this.teachersBindingSource.DataMember = "Teachers";
            this.teachersBindingSource.DataSource = this.kazakovDataSet;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.button15);
            this.tabPage2.Controls.Add(this.button12);
            this.tabPage2.Controls.Add(this.label12);
            this.tabPage2.Controls.Add(this.label11);
            this.tabPage2.Controls.Add(this.label10);
            this.tabPage2.Controls.Add(this.label9);
            this.tabPage2.Controls.Add(this.label8);
            this.tabPage2.Controls.Add(this.textBox9);
            this.tabPage2.Controls.Add(this.textBox8);
            this.tabPage2.Controls.Add(this.textBox7);
            this.tabPage2.Controls.Add(this.textBox6);
            this.tabPage2.Controls.Add(this.textBox5);
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.Controls.Add(this.label3);
            this.tabPage2.Controls.Add(this.label2);
            this.tabPage2.Controls.Add(this.label1);
            this.tabPage2.Controls.Add(this.button11);
            this.tabPage2.Controls.Add(this.dataGridView10);
            this.tabPage2.Controls.Add(this.button8);
            this.tabPage2.Controls.Add(this.button7);
            this.tabPage2.Controls.Add(this.button6);
            this.tabPage2.Controls.Add(this.button4);
            this.tabPage2.Controls.Add(this.button3);
            this.tabPage2.Controls.Add(this.dataGridView9);
            this.tabPage2.Controls.Add(this.dataGridView8);
            this.tabPage2.Controls.Add(this.dataGridView7);
            this.tabPage2.Controls.Add(this.dataGridView6);
            this.tabPage2.Controls.Add(this.dataGridView5);
            this.tabPage2.Location = new System.Drawing.Point(4, 29);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabPage2.Size = new System.Drawing.Size(1210, 626);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Программное обеспечение";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // button15
            // 
            this.button15.Location = new System.Drawing.Point(1028, 581);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(138, 35);
            this.button15.TabIndex = 30;
            this.button15.Text = "Экспорт";
            this.button15.UseVisualStyleBackColor = true;
            this.button15.Click += new System.EventHandler(this.button15_Click);
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(485, 30);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(129, 36);
            this.button12.TabIndex = 27;
            this.button12.Text = "Обновить ПО";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Visible = false;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(680, 331);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(128, 20);
            this.label12.TabIndex = 26;
            this.label12.Text = "Специальность";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(1060, 331);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(99, 20);
            this.label11.TabIndex = 25;
            this.label11.Text = "№ кабинета";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(976, 30);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(112, 20);
            this.label10.TabIndex = 24;
            this.label10.Text = "Тип лицензии";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(266, 334);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(122, 20);
            this.label9.TabIndex = 23;
            this.label9.Text = "Наименование";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(178, 26);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(150, 20);
            this.label8.TabIndex = 22;
            this.label8.Text = "Наименование ПО";
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(1062, 354);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(94, 26);
            this.textBox9.TabIndex = 21;
            this.textBox9.TextChanged += new System.EventHandler(this.textBox9_TextChanged);
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(684, 354);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(147, 26);
            this.textBox8.TabIndex = 20;
            this.textBox8.TextChanged += new System.EventHandler(this.textBox8_TextChanged);
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(270, 354);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(147, 26);
            this.textBox7.TabIndex = 19;
            this.textBox7.TextChanged += new System.EventHandler(this.textBox7_TextChanged);
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(980, 53);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(147, 26);
            this.textBox6.TabIndex = 18;
            this.textBox6.TextChanged += new System.EventHandler(this.textBox6_TextChanged);
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(182, 54);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(147, 26);
            this.textBox5.TabIndex = 17;
            this.textBox5.TextChanged += new System.EventHandler(this.textBox5_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(48, 61);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(33, 20);
            this.label4.TabIndex = 15;
            this.label4.Text = "ПО";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(856, 61);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(83, 20);
            this.label3.TabIndex = 14;
            this.label3.Text = "Лицензия";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(856, 363);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(31, 20);
            this.label2.TabIndex = 13;
            this.label2.Text = "ПК";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(48, 360);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(79, 20);
            this.label1.TabIndex = 12;
            this.label1.Text = "Предмет";
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(856, 299);
            this.button11.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(177, 35);
            this.button11.TabIndex = 11;
            this.button11.Text = "Изменить лицензию";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Visible = false;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // dataGridView10
            // 
            this.dataGridView10.AllowUserToAddRows = false;
            this.dataGridView10.AllowUserToDeleteRows = false;
            this.dataGridView10.AllowUserToResizeColumns = false;
            this.dataGridView10.AllowUserToResizeRows = false;
            this.dataGridView10.AutoGenerateColumns = false;
            this.dataGridView10.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView10.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView10.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.lnumDataGridViewTextBoxColumn,
            this.lnamDataGridViewTextBoxColumn,
            this.dlitDataGridViewTextBoxColumn});
            this.dataGridView10.DataSource = this.licenseBindingSource;
            this.dataGridView10.Location = new System.Drawing.Point(856, 84);
            this.dataGridView10.Name = "dataGridView10";
            this.dataGridView10.ReadOnly = true;
            this.dataGridView10.RowHeadersVisible = false;
            this.dataGridView10.RowHeadersWidth = 62;
            this.dataGridView10.RowTemplate.Height = 28;
            this.dataGridView10.Size = new System.Drawing.Size(300, 207);
            this.dataGridView10.TabIndex = 10;
            this.dataGridView10.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView10_CellContentClick);
            // 
            // lnumDataGridViewTextBoxColumn
            // 
            this.lnumDataGridViewTextBoxColumn.DataPropertyName = "lnum";
            this.lnumDataGridViewTextBoxColumn.FillWeight = 50F;
            this.lnumDataGridViewTextBoxColumn.HeaderText = "Код";
            this.lnumDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.lnumDataGridViewTextBoxColumn.Name = "lnumDataGridViewTextBoxColumn";
            this.lnumDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // lnamDataGridViewTextBoxColumn
            // 
            this.lnamDataGridViewTextBoxColumn.DataPropertyName = "lnam";
            this.lnamDataGridViewTextBoxColumn.HeaderText = "Тип лицензии";
            this.lnamDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.lnamDataGridViewTextBoxColumn.Name = "lnamDataGridViewTextBoxColumn";
            this.lnamDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // dlitDataGridViewTextBoxColumn
            // 
            this.dlitDataGridViewTextBoxColumn.DataPropertyName = "dlit";
            this.dlitDataGridViewTextBoxColumn.FillWeight = 125F;
            this.dlitDataGridViewTextBoxColumn.HeaderText = "Длительность, лет";
            this.dlitDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.dlitDataGridViewTextBoxColumn.Name = "dlitDataGridViewTextBoxColumn";
            this.dlitDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // licenseBindingSource
            // 
            this.licenseBindingSource.DataMember = "License";
            this.licenseBindingSource.DataSource = this.kazakovDataSet;
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(856, 581);
            this.button8.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(150, 35);
            this.button8.TabIndex = 9;
            this.button8.Text = "Изменить ПК";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Visible = false;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(48, 299);
            this.button7.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(159, 35);
            this.button7.TabIndex = 8;
            this.button7.Text = "Изменить ПО";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Visible = false;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(505, 581);
            this.button6.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(159, 35);
            this.button6.TabIndex = 7;
            this.button6.Text = "Сброс фильтра";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(48, 581);
            this.button4.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(194, 35);
            this.button4.TabIndex = 6;
            this.button4.Text = "Изменить предмет";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Visible = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(48, 10);
            this.button3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(112, 35);
            this.button3.TabIndex = 5;
            this.button3.Text = "Добавить";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Visible = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // dataGridView9
            // 
            this.dataGridView9.AllowUserToAddRows = false;
            this.dataGridView9.AllowUserToDeleteRows = false;
            this.dataGridView9.AllowUserToResizeColumns = false;
            this.dataGridView9.AllowUserToResizeRows = false;
            this.dataGridView9.AutoGenerateColumns = false;
            this.dataGridView9.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView9.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView9.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.pnumDataGridViewTextBoxColumn2,
            this.pnamDataGridViewTextBoxColumn1,
            this.labhoursDataGridViewTextBoxColumn1,
            this.specDataGridViewTextBoxColumn1});
            this.dataGridView9.DataSource = this.predmetBindingSource;
            this.dataGridView9.Location = new System.Drawing.Point(48, 386);
            this.dataGridView9.Name = "dataGridView9";
            this.dataGridView9.ReadOnly = true;
            this.dataGridView9.RowHeadersVisible = false;
            this.dataGridView9.RowHeadersWidth = 62;
            this.dataGridView9.RowTemplate.Height = 28;
            this.dataGridView9.Size = new System.Drawing.Size(802, 187);
            this.dataGridView9.TabIndex = 4;
            this.dataGridView9.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView9_CellClick);
            // 
            // pnumDataGridViewTextBoxColumn2
            // 
            this.pnumDataGridViewTextBoxColumn2.DataPropertyName = "pnum";
            this.pnumDataGridViewTextBoxColumn2.HeaderText = "Код";
            this.pnumDataGridViewTextBoxColumn2.MinimumWidth = 8;
            this.pnumDataGridViewTextBoxColumn2.Name = "pnumDataGridViewTextBoxColumn2";
            this.pnumDataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // pnamDataGridViewTextBoxColumn1
            // 
            this.pnamDataGridViewTextBoxColumn1.DataPropertyName = "pnam";
            this.pnamDataGridViewTextBoxColumn1.HeaderText = "Наименование";
            this.pnamDataGridViewTextBoxColumn1.MinimumWidth = 8;
            this.pnamDataGridViewTextBoxColumn1.Name = "pnamDataGridViewTextBoxColumn1";
            this.pnamDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // labhoursDataGridViewTextBoxColumn1
            // 
            this.labhoursDataGridViewTextBoxColumn1.DataPropertyName = "lab_hours";
            this.labhoursDataGridViewTextBoxColumn1.HeaderText = "Лабораторные, часы";
            this.labhoursDataGridViewTextBoxColumn1.MinimumWidth = 8;
            this.labhoursDataGridViewTextBoxColumn1.Name = "labhoursDataGridViewTextBoxColumn1";
            this.labhoursDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // specDataGridViewTextBoxColumn1
            // 
            this.specDataGridViewTextBoxColumn1.DataPropertyName = "spec";
            this.specDataGridViewTextBoxColumn1.HeaderText = "Специальность";
            this.specDataGridViewTextBoxColumn1.MinimumWidth = 8;
            this.specDataGridViewTextBoxColumn1.Name = "specDataGridViewTextBoxColumn1";
            this.specDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // dataGridView8
            // 
            this.dataGridView8.AllowUserToAddRows = false;
            this.dataGridView8.AllowUserToDeleteRows = false;
            this.dataGridView8.AllowUserToResizeColumns = false;
            this.dataGridView8.AllowUserToResizeRows = false;
            this.dataGridView8.AutoGenerateColumns = false;
            this.dataGridView8.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView8.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView8.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.progDataGridViewTextBoxColumn,
            this.predmDataGridViewTextBoxColumn});
            this.dataGridView8.DataSource = this.progPredBindingSource;
            this.dataGridView8.Location = new System.Drawing.Point(1257, 84);
            this.dataGridView8.Name = "dataGridView8";
            this.dataGridView8.ReadOnly = true;
            this.dataGridView8.RowHeadersVisible = false;
            this.dataGridView8.RowHeadersWidth = 62;
            this.dataGridView8.RowTemplate.Height = 28;
            this.dataGridView8.Size = new System.Drawing.Size(238, 185);
            this.dataGridView8.TabIndex = 3;
            this.dataGridView8.Visible = false;
            // 
            // progDataGridViewTextBoxColumn
            // 
            this.progDataGridViewTextBoxColumn.DataPropertyName = "prog";
            this.progDataGridViewTextBoxColumn.HeaderText = "prog";
            this.progDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.progDataGridViewTextBoxColumn.Name = "progDataGridViewTextBoxColumn";
            this.progDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // predmDataGridViewTextBoxColumn
            // 
            this.predmDataGridViewTextBoxColumn.DataPropertyName = "predm";
            this.predmDataGridViewTextBoxColumn.HeaderText = "predm";
            this.predmDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.predmDataGridViewTextBoxColumn.Name = "predmDataGridViewTextBoxColumn";
            this.predmDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // progPredBindingSource
            // 
            this.progPredBindingSource.DataMember = "ProgPred";
            this.progPredBindingSource.DataSource = this.kazakovDataSet;
            // 
            // dataGridView7
            // 
            this.dataGridView7.AllowUserToAddRows = false;
            this.dataGridView7.AllowUserToDeleteRows = false;
            this.dataGridView7.AllowUserToResizeColumns = false;
            this.dataGridView7.AllowUserToResizeRows = false;
            this.dataGridView7.AutoGenerateColumns = false;
            this.dataGridView7.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView7.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView7.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.progDataGridViewTextBoxColumn1,
            this.pcDataGridViewTextBoxColumn});
            this.dataGridView7.DataSource = this.installBindingSource;
            this.dataGridView7.Location = new System.Drawing.Point(1257, 320);
            this.dataGridView7.Name = "dataGridView7";
            this.dataGridView7.ReadOnly = true;
            this.dataGridView7.RowHeadersVisible = false;
            this.dataGridView7.RowHeadersWidth = 62;
            this.dataGridView7.RowTemplate.Height = 28;
            this.dataGridView7.Size = new System.Drawing.Size(238, 209);
            this.dataGridView7.TabIndex = 2;
            this.dataGridView7.Visible = false;
            // 
            // progDataGridViewTextBoxColumn1
            // 
            this.progDataGridViewTextBoxColumn1.DataPropertyName = "prog";
            this.progDataGridViewTextBoxColumn1.HeaderText = "prog";
            this.progDataGridViewTextBoxColumn1.MinimumWidth = 8;
            this.progDataGridViewTextBoxColumn1.Name = "progDataGridViewTextBoxColumn1";
            this.progDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // pcDataGridViewTextBoxColumn
            // 
            this.pcDataGridViewTextBoxColumn.DataPropertyName = "pc";
            this.pcDataGridViewTextBoxColumn.HeaderText = "pc";
            this.pcDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.pcDataGridViewTextBoxColumn.Name = "pcDataGridViewTextBoxColumn";
            this.pcDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // installBindingSource
            // 
            this.installBindingSource.DataMember = "Install";
            this.installBindingSource.DataSource = this.kazakovDataSet;
            // 
            // dataGridView6
            // 
            this.dataGridView6.AllowUserToAddRows = false;
            this.dataGridView6.AllowUserToDeleteRows = false;
            this.dataGridView6.AllowUserToResizeColumns = false;
            this.dataGridView6.AllowUserToResizeRows = false;
            this.dataGridView6.AutoGenerateColumns = false;
            this.dataGridView6.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView6.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView6.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.pCnumDataGridViewTextBoxColumn,
            this.pCnetDataGridViewTextBoxColumn,
            this.kabDataGridViewTextBoxColumn,
            this.knamDataGridViewTextBoxColumn1});
            this.dataGridView6.DataSource = this.pC1BindingSource;
            this.dataGridView6.Location = new System.Drawing.Point(856, 386);
            this.dataGridView6.Name = "dataGridView6";
            this.dataGridView6.ReadOnly = true;
            this.dataGridView6.RowHeadersVisible = false;
            this.dataGridView6.RowHeadersWidth = 62;
            this.dataGridView6.RowTemplate.Height = 28;
            this.dataGridView6.Size = new System.Drawing.Size(300, 187);
            this.dataGridView6.TabIndex = 1;
            this.dataGridView6.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView6_CellClick);
            // 
            // pCnumDataGridViewTextBoxColumn
            // 
            this.pCnumDataGridViewTextBoxColumn.DataPropertyName = "PCnum";
            this.pCnumDataGridViewTextBoxColumn.HeaderText = "Код";
            this.pCnumDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.pCnumDataGridViewTextBoxColumn.Name = "pCnumDataGridViewTextBoxColumn";
            this.pCnumDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // pCnetDataGridViewTextBoxColumn
            // 
            this.pCnetDataGridViewTextBoxColumn.DataPropertyName = "PCnet";
            this.pCnetDataGridViewTextBoxColumn.HeaderText = "Сетевое имя";
            this.pCnetDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.pCnetDataGridViewTextBoxColumn.Name = "pCnetDataGridViewTextBoxColumn";
            this.pCnetDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // kabDataGridViewTextBoxColumn
            // 
            this.kabDataGridViewTextBoxColumn.DataPropertyName = "Kab";
            this.kabDataGridViewTextBoxColumn.HeaderText = "Kab";
            this.kabDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.kabDataGridViewTextBoxColumn.Name = "kabDataGridViewTextBoxColumn";
            this.kabDataGridViewTextBoxColumn.ReadOnly = true;
            this.kabDataGridViewTextBoxColumn.Visible = false;
            // 
            // knamDataGridViewTextBoxColumn1
            // 
            this.knamDataGridViewTextBoxColumn1.DataPropertyName = "knam";
            this.knamDataGridViewTextBoxColumn1.HeaderText = "Кабинет";
            this.knamDataGridViewTextBoxColumn1.MinimumWidth = 8;
            this.knamDataGridViewTextBoxColumn1.Name = "knamDataGridViewTextBoxColumn1";
            this.knamDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // pC1BindingSource
            // 
            this.pC1BindingSource.DataMember = "PC1";
            this.pC1BindingSource.DataSource = this.kazakovDataSet;
            // 
            // dataGridView5
            // 
            this.dataGridView5.AllowUserToAddRows = false;
            this.dataGridView5.AllowUserToDeleteRows = false;
            this.dataGridView5.AllowUserToResizeColumns = false;
            this.dataGridView5.AllowUserToResizeRows = false;
            this.dataGridView5.AutoGenerateColumns = false;
            this.dataGridView5.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView5.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView5.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.prnumDataGridViewTextBoxColumn,
            this.prnamDataGridViewTextBoxColumn,
            this.versionDataGridViewTextBoxColumn,
            this.licenseDataGridViewTextBoxColumn,
            this.instdatDataGridViewTextBoxColumn,
            this.exprdatDataGridViewTextBoxColumn,
            this.valueDataGridViewTextBoxColumn});
            this.dataGridView5.DataSource = this.programsBindingSource;
            this.dataGridView5.Location = new System.Drawing.Point(48, 84);
            this.dataGridView5.Name = "dataGridView5";
            this.dataGridView5.ReadOnly = true;
            this.dataGridView5.RowHeadersVisible = false;
            this.dataGridView5.RowHeadersWidth = 62;
            this.dataGridView5.RowTemplate.Height = 28;
            this.dataGridView5.Size = new System.Drawing.Size(802, 207);
            this.dataGridView5.TabIndex = 0;
            this.dataGridView5.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView5_CellClick);
            // 
            // prnumDataGridViewTextBoxColumn
            // 
            this.prnumDataGridViewTextBoxColumn.DataPropertyName = "prnum";
            this.prnumDataGridViewTextBoxColumn.HeaderText = "Код";
            this.prnumDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.prnumDataGridViewTextBoxColumn.Name = "prnumDataGridViewTextBoxColumn";
            this.prnumDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // prnamDataGridViewTextBoxColumn
            // 
            this.prnamDataGridViewTextBoxColumn.DataPropertyName = "prnam";
            this.prnamDataGridViewTextBoxColumn.HeaderText = "Наименование";
            this.prnamDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.prnamDataGridViewTextBoxColumn.Name = "prnamDataGridViewTextBoxColumn";
            this.prnamDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // versionDataGridViewTextBoxColumn
            // 
            this.versionDataGridViewTextBoxColumn.DataPropertyName = "version";
            this.versionDataGridViewTextBoxColumn.HeaderText = "Версия";
            this.versionDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.versionDataGridViewTextBoxColumn.Name = "versionDataGridViewTextBoxColumn";
            this.versionDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // licenseDataGridViewTextBoxColumn
            // 
            this.licenseDataGridViewTextBoxColumn.DataPropertyName = "license";
            this.licenseDataGridViewTextBoxColumn.HeaderText = "Лицензия";
            this.licenseDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.licenseDataGridViewTextBoxColumn.Name = "licenseDataGridViewTextBoxColumn";
            this.licenseDataGridViewTextBoxColumn.ReadOnly = true;
            this.licenseDataGridViewTextBoxColumn.Visible = false;
            // 
            // instdatDataGridViewTextBoxColumn
            // 
            this.instdatDataGridViewTextBoxColumn.DataPropertyName = "inst_dat";
            this.instdatDataGridViewTextBoxColumn.HeaderText = "Дата установки";
            this.instdatDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.instdatDataGridViewTextBoxColumn.Name = "instdatDataGridViewTextBoxColumn";
            this.instdatDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // exprdatDataGridViewTextBoxColumn
            // 
            this.exprdatDataGridViewTextBoxColumn.DataPropertyName = "expr_dat";
            this.exprdatDataGridViewTextBoxColumn.HeaderText = "Срок действия";
            this.exprdatDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.exprdatDataGridViewTextBoxColumn.Name = "exprdatDataGridViewTextBoxColumn";
            this.exprdatDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // valueDataGridViewTextBoxColumn
            // 
            this.valueDataGridViewTextBoxColumn.DataPropertyName = "value";
            this.valueDataGridViewTextBoxColumn.HeaderText = "Количество";
            this.valueDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.valueDataGridViewTextBoxColumn.Name = "valueDataGridViewTextBoxColumn";
            this.valueDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // programsBindingSource
            // 
            this.programsBindingSource.DataMember = "Programs";
            this.programsBindingSource.DataSource = this.kazakovDataSet;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.button13);
            this.tabPage3.Controls.Add(this.dataGridView11);
            this.tabPage3.Location = new System.Drawing.Point(4, 29);
            this.tabPage3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabPage3.Size = new System.Drawing.Size(1210, 626);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Сотрудники";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(187, 44);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(126, 41);
            this.button13.TabIndex = 1;
            this.button13.Text = "Регистрация";
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // dataGridView11
            // 
            this.dataGridView11.AllowUserToAddRows = false;
            this.dataGridView11.AllowUserToDeleteRows = false;
            this.dataGridView11.AllowUserToResizeColumns = false;
            this.dataGridView11.AllowUserToResizeRows = false;
            this.dataGridView11.AutoGenerateColumns = false;
            this.dataGridView11.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView11.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView11.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.snumDataGridViewTextBoxColumn,
            this.snamDataGridViewTextBoxColumn,
            this.roleDataGridViewTextBoxColumn});
            this.dataGridView11.DataSource = this.sotrBindingSource;
            this.dataGridView11.Location = new System.Drawing.Point(187, 101);
            this.dataGridView11.Name = "dataGridView11";
            this.dataGridView11.ReadOnly = true;
            this.dataGridView11.RowHeadersVisible = false;
            this.dataGridView11.RowHeadersWidth = 62;
            this.dataGridView11.RowTemplate.Height = 28;
            this.dataGridView11.Size = new System.Drawing.Size(772, 150);
            this.dataGridView11.TabIndex = 0;
            // 
            // snumDataGridViewTextBoxColumn
            // 
            this.snumDataGridViewTextBoxColumn.DataPropertyName = "snum";
            this.snumDataGridViewTextBoxColumn.HeaderText = "Код";
            this.snumDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.snumDataGridViewTextBoxColumn.Name = "snumDataGridViewTextBoxColumn";
            this.snumDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // snamDataGridViewTextBoxColumn
            // 
            this.snamDataGridViewTextBoxColumn.DataPropertyName = "snam";
            this.snamDataGridViewTextBoxColumn.HeaderText = "Логин";
            this.snamDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.snamDataGridViewTextBoxColumn.Name = "snamDataGridViewTextBoxColumn";
            this.snamDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // roleDataGridViewTextBoxColumn
            // 
            this.roleDataGridViewTextBoxColumn.DataPropertyName = "role";
            this.roleDataGridViewTextBoxColumn.HeaderText = "Роль";
            this.roleDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.roleDataGridViewTextBoxColumn.Name = "roleDataGridViewTextBoxColumn";
            this.roleDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // sotrBindingSource
            // 
            this.sotrBindingSource.DataMember = "Sotr";
            this.sotrBindingSource.DataSource = this.kazakovDataSet;
            // 
            // менюToolStripMenuItem
            // 
            this.менюToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.обновитьТаблицыToolStripMenuItem,
            this.статистикаОбновленияToolStripMenuItem,
            this.сменитьПользователяToolStripMenuItem,
            this.выходToolStripMenuItem});
            this.менюToolStripMenuItem.Name = "менюToolStripMenuItem";
            this.менюToolStripMenuItem.Size = new System.Drawing.Size(78, 29);
            this.менюToolStripMenuItem.Text = "Меню";
            // 
            // обновитьТаблицыToolStripMenuItem
            // 
            this.обновитьТаблицыToolStripMenuItem.Name = "обновитьТаблицыToolStripMenuItem";
            this.обновитьТаблицыToolStripMenuItem.Size = new System.Drawing.Size(305, 34);
            this.обновитьТаблицыToolStripMenuItem.Text = "Обновить таблицы";
            this.обновитьТаблицыToolStripMenuItem.Click += new System.EventHandler(this.обновитьToolStripMenuItem_Click);
            // 
            // статистикаОбновленияToolStripMenuItem
            // 
            this.статистикаОбновленияToolStripMenuItem.Name = "статистикаОбновленияToolStripMenuItem";
            this.статистикаОбновленияToolStripMenuItem.Size = new System.Drawing.Size(305, 34);
            this.статистикаОбновленияToolStripMenuItem.Text = "Статистика обновления";
            this.статистикаОбновленияToolStripMenuItem.Click += new System.EventHandler(this.статистикаОбновленияToolStripMenuItem_Click);
            // 
            // сменитьПользователяToolStripMenuItem
            // 
            this.сменитьПользователяToolStripMenuItem.Name = "сменитьПользователяToolStripMenuItem";
            this.сменитьПользователяToolStripMenuItem.Size = new System.Drawing.Size(305, 34);
            this.сменитьПользователяToolStripMenuItem.Text = "Сменить пользователя";
            this.сменитьПользователяToolStripMenuItem.Click += new System.EventHandler(this.сменитьПользователяToolStripMenuItem_Click);
            // 
            // выходToolStripMenuItem
            // 
            this.выходToolStripMenuItem.Name = "выходToolStripMenuItem";
            this.выходToolStripMenuItem.Size = new System.Drawing.Size(305, 34);
            this.выходToolStripMenuItem.Text = "Выход";
            this.выходToolStripMenuItem.Click += new System.EventHandler(this.выходToolStripMenuItem_Click);
            // 
            // экспортToolStripMenuItem
            // 
            this.экспортToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.преподавателиToolStripMenuItem,
            this.программноеОбеспечениеToolStripMenuItem});
            this.экспортToolStripMenuItem.Name = "экспортToolStripMenuItem";
            this.экспортToolStripMenuItem.Size = new System.Drawing.Size(95, 29);
            this.экспортToolStripMenuItem.Text = "Экспорт";
            this.экспортToolStripMenuItem.Visible = false;
            // 
            // преподавателиToolStripMenuItem
            // 
            this.преподавателиToolStripMenuItem.Name = "преподавателиToolStripMenuItem";
            this.преподавателиToolStripMenuItem.Size = new System.Drawing.Size(342, 34);
            this.преподавателиToolStripMenuItem.Text = "Преподаватели";
            this.преподавателиToolStripMenuItem.Click += new System.EventHandler(this.преподавателиToolStripMenuItem_Click);
            // 
            // программноеОбеспечениеToolStripMenuItem
            // 
            this.программноеОбеспечениеToolStripMenuItem.Name = "программноеОбеспечениеToolStripMenuItem";
            this.программноеОбеспечениеToolStripMenuItem.Size = new System.Drawing.Size(342, 34);
            this.программноеОбеспечениеToolStripMenuItem.Text = "Программное обеспечение";
            // 
            // оПрограммеToolStripMenuItem
            // 
            this.оПрограммеToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.оПрограммеToolStripMenuItem1});
            this.оПрограммеToolStripMenuItem.Name = "оПрограммеToolStripMenuItem";
            this.оПрограммеToolStripMenuItem.Size = new System.Drawing.Size(141, 29);
            this.оПрограммеToolStripMenuItem.Text = "О программе";
            // 
            // оПрограммеToolStripMenuItem1
            // 
            this.оПрограммеToolStripMenuItem1.Name = "оПрограммеToolStripMenuItem1";
            this.оПрограммеToolStripMenuItem1.Size = new System.Drawing.Size(227, 34);
            this.оПрограммеToolStripMenuItem1.Text = "О программе";
            this.оПрограммеToolStripMenuItem1.Click += new System.EventHandler(this.оПрограммеToolStripMenuItem1_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.GripMargin = new System.Windows.Forms.Padding(2, 2, 0, 2);
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.менюToolStripMenuItem,
            this.экспортToolStripMenuItem,
            this.оПрограммеToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1218, 33);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // teachersTableAdapter
            // 
            this.teachersTableAdapter.ClearBeforeFill = true;
            // 
            // kabsTableAdapter
            // 
            this.kabsTableAdapter.ClearBeforeFill = true;
            // 
            // predmetTableAdapter
            // 
            this.predmetTableAdapter.ClearBeforeFill = true;
            // 
            // prepodavTableAdapter
            // 
            this.prepodavTableAdapter.ClearBeforeFill = true;
            // 
            // programsTableAdapter
            // 
            this.programsTableAdapter.ClearBeforeFill = true;
            // 
            // licenseTableAdapter
            // 
            this.licenseTableAdapter.ClearBeforeFill = true;
            // 
            // pCBindingSource
            // 
            this.pCBindingSource.DataMember = "PC";
            this.pCBindingSource.DataSource = this.kazakovDataSet;
            // 
            // pCTableAdapter
            // 
            this.pCTableAdapter.ClearBeforeFill = true;
            // 
            // pC1TableAdapter
            // 
            this.pC1TableAdapter.ClearBeforeFill = true;
            // 
            // sotrTableAdapter
            // 
            this.sotrTableAdapter.ClearBeforeFill = true;
            // 
            // progPredTableAdapter
            // 
            this.progPredTableAdapter.ClearBeforeFill = true;
            // 
            // installTableAdapter
            // 
            this.installTableAdapter.ClearBeforeFill = true;
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1218, 692);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Main";
            this.Text = "Учет программного обеспечения цикловой комиссии";
            this.Activated += new System.EventHandler(this.Main_Activated);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Main_FormClosing);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Main_FormClosed);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.prepodavBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kazakovDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kabsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.predmetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.teachersBindingSource)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.licenseBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.progPredBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.installBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pC1BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.programsBindingSource)).EndInit();
            this.tabPage3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sotrBindingSource)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pCBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridView dataGridView10;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.DataGridView dataGridView4;
        private System.Windows.Forms.DataGridView dataGridView5;
        private System.Windows.Forms.DataGridView dataGridView6;
        private System.Windows.Forms.DataGridView dataGridView7;
        private System.Windows.Forms.DataGridView dataGridView9;
        private System.Windows.Forms.DataGridView dataGridView8;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.DataGridView dataGridView11;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.DataGridViewTextBoxColumn tnumDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn pnumDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn knumDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn knamDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn teachDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pnumDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pnamDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn labhoursDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn specDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tnumDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tfamDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tnamDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn totchDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dolgDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn lnumDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn lnamDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dlitDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pnumDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn pnamDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn labhoursDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn specDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn progDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn predmDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn progDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn pcDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn prnumDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn prnamDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn versionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn licenseDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn instdatDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn exprdatDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn valueDataGridViewTextBoxColumn;
        private System.Windows.Forms.ToolStripMenuItem менюToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem обновитьТаблицыToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem сменитьПользователяToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem выходToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem статистикаОбновленияToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem экспортToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem преподавателиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem программноеОбеспечениеToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem оПрограммеToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem оПрограммеToolStripMenuItem1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private KazakovDataSet kazakovDataSet;
        private System.Windows.Forms.BindingSource teachersBindingSource;
        private KazakovDataSetTableAdapters.TeachersTableAdapter teachersTableAdapter;
        private System.Windows.Forms.BindingSource kabsBindingSource;
        private KazakovDataSetTableAdapters.KabsTableAdapter kabsTableAdapter;
        private System.Windows.Forms.BindingSource predmetBindingSource;
        private KazakovDataSetTableAdapters.PredmetTableAdapter predmetTableAdapter;
        private System.Windows.Forms.BindingSource prepodavBindingSource;
        private KazakovDataSetTableAdapters.PrepodavTableAdapter prepodavTableAdapter;
        private System.Windows.Forms.BindingSource programsBindingSource;
        private KazakovDataSetTableAdapters.ProgramsTableAdapter programsTableAdapter;
        private System.Windows.Forms.BindingSource licenseBindingSource;
        private KazakovDataSetTableAdapters.LicenseTableAdapter licenseTableAdapter;
        private System.Windows.Forms.BindingSource pCBindingSource;
        private KazakovDataSetTableAdapters.PCTableAdapter pCTableAdapter;
        private System.Windows.Forms.BindingSource pC1BindingSource;
        private KazakovDataSetTableAdapters.PC1TableAdapter pC1TableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn pCnumDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pCnetDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn kabDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn knamDataGridViewTextBoxColumn1;
        private System.Windows.Forms.BindingSource sotrBindingSource;
        private KazakovDataSetTableAdapters.SotrTableAdapter sotrTableAdapter;
        private System.Windows.Forms.BindingSource progPredBindingSource;
        private KazakovDataSetTableAdapters.ProgPredTableAdapter progPredTableAdapter;
        private System.Windows.Forms.BindingSource installBindingSource;
        private KazakovDataSetTableAdapters.InstallTableAdapter installTableAdapter;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.DataGridViewTextBoxColumn snumDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn snamDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn roleDataGridViewTextBoxColumn;
    }
}

